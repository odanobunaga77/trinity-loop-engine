# Trinity Loop Engine

This is the AI recursive core for Trinity Loop Engine, deployable via Vercel.

## Setup

### Environment Variables
- `OPENAI_API_KEY`: Your OpenAI secret key
- `TLE_MODE`: Operating mode (e.g. `quantum`, `classic`)
- `RECURSION_LIMIT`: Depth of loop stack

### Deployment (Vercel CLI)

```bash
npm install -g vercel
vercel login
vercel link
vercel env add OPENAI_API_KEY production
vercel --prod
```

Endpoints:
- `/`: Root welcome
- `/predict`: Initiate recursive logic
