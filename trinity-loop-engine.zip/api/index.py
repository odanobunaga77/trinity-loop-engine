from fastapi import FastAPI
from dotenv import load_dotenv
import os

load_dotenv()
app = FastAPI()

OPENAI_KEY = os.getenv("OPENAI_API_KEY", "not_set")

@app.get("/")
def root():
    return {"message": "Welcome to Trinity Loop Engine", "api_key": "hidden"}

@app.get("/predict")
def predict():
    mode = os.getenv("TLE_MODE", "default")
    return {"result": f"Recursive logic activated in mode: {mode}"}
